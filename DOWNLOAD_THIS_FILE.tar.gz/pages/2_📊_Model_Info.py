import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

st.set_page_config(page_title="Model Information", page_icon="📊", layout="wide")

def main():
    st.title("📊 Model Information & Performance")
    st.markdown("### Deep Learning Models for Forest Fire Prediction")
    
    # Model selection
    models = {
        "CNN-ResNet50": {
            "description": "Convolutional Neural Network based on ResNet50 architecture for satellite image analysis",
            "accuracy": 94.2,
            "precision": 92.8,
            "recall": 95.1,
            "f1_score": 93.9,
            "training_samples": 50000,
            "validation_samples": 12500,
            "parameters": "25.6M",
            "training_time": "48 hours"
        },
        "LSTM-Weather": {
            "description": "Long Short-Term Memory network for temporal weather pattern analysis",
            "accuracy": 89.7,
            "precision": 87.3,
            "recall": 91.2,
            "f1_score": 89.2,
            "training_samples": 75000,
            "validation_samples": 18750,
            "parameters": "2.1M",
            "training_time": "12 hours"
        },
        "Ensemble-Hybrid": {
            "description": "Hybrid ensemble combining CNN and LSTM with gradient boosting",
            "accuracy": 96.1,
            "precision": 95.4,
            "recall": 96.8,
            "f1_score": 96.1,
            "training_samples": 85000,
            "validation_samples": 21250,
            "parameters": "32.4M",
            "training_time": "72 hours"
        },
        "Transformer-Satellite": {
            "description": "Vision Transformer for multi-spectral satellite imagery analysis",
            "accuracy": 93.5,
            "precision": 91.9,
            "recall": 94.7,
            "f1_score": 93.3,
            "training_samples": 60000,
            "validation_samples": 15000,
            "parameters": "86.2M",
            "training_time": "96 hours"
        }
    }
    
    # Model selection sidebar
    st.sidebar.header("🎛️ Model Selection")
    selected_model = st.sidebar.selectbox("Choose a model to explore:", list(models.keys()))
    
    # Main content tabs
    tab1, tab2, tab3, tab4 = st.tabs(["🏗️ Architecture", "📈 Performance", "🧠 Methodology", "⚙️ Training Details"])
    
    with tab1:
        st.header(f"🏗️ {selected_model} Architecture")
        
        model_info = models[selected_model]
        
        # Model description
        st.subheader("📝 Description")
        st.write(model_info["description"])
        
        # Model architecture visualization
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.subheader("🔧 Architecture Diagram")
            
            if "CNN" in selected_model:
                st.markdown("""
                ```
                Input (224x224x3) → Conv2D(64) → BatchNorm → ReLU
                     ↓
                ResNet50 Backbone (Pre-trained)
                     ↓
                GlobalAveragePooling2D
                     ↓
                Dense(512) → Dropout(0.5) → ReLU
                     ↓
                Dense(256) → Dropout(0.3) → ReLU
                     ↓
                Dense(1) → Sigmoid → Fire Risk Probability
                ```
                """)
            elif "LSTM" in selected_model:
                st.markdown("""
                ```
                Input (seq_len, features) → Embedding
                     ↓
                LSTM(128) → Dropout(0.3)
                     ↓
                LSTM(64) → Dropout(0.3)
                     ↓
                Dense(32) → ReLU
                     ↓
                Dense(1) → Sigmoid → Fire Risk Probability
                ```
                """)
            elif "Ensemble" in selected_model:
                st.markdown("""
                ```
                CNN Branch:
                Input → ResNet50 → GlobalAvgPool → Dense(256)
                        ↓
                LSTM Branch:
                Time Series → LSTM(128) → LSTM(64) → Dense(128)
                        ↓
                Traditional ML:
                Features → Random Forest → Predictions
                        ↓
                Ensemble Combination:
                Weighted Average → Final Prediction
                ```
                """)
            else:  # Transformer
                st.markdown("""
                ```
                Input Images → Patch Embedding → Position Encoding
                        ↓
                Multi-Head Self-Attention (12 layers)
                        ↓
                Layer Normalization → Feed Forward
                        ↓
                Classification Head → Fire Risk Probability
                ```
                """)
        
        with col2:
            st.subheader("📊 Key Metrics")
            
            # Display key metrics as metrics
            st.metric("Accuracy", f"{model_info['accuracy']:.1f}%")
            st.metric("Precision", f"{model_info['precision']:.1f}%")
            st.metric("Recall", f"{model_info['recall']:.1f}%")
            st.metric("F1-Score", f"{model_info['f1_score']:.1f}%")
            
            # Model size info
            st.subheader("🔧 Model Details")
            st.text(f"Parameters: {model_info['parameters']}")
            st.text(f"Training Time: {model_info['training_time']}")
            st.text(f"Training Samples: {model_info['training_samples']:,}")
            st.text(f"Validation Samples: {model_info['validation_samples']:,}")
    
    with tab2:
        st.header("📈 Model Performance Analysis")
        
        # Performance comparison chart
        performance_data = pd.DataFrame([
            {"Model": model, "Accuracy": info["accuracy"], "Precision": info["precision"], 
             "Recall": info["recall"], "F1-Score": info["f1_score"]}
            for model, info in models.items()
        ])
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Radar chart for performance metrics
            fig = go.Figure()
            
            for _, row in performance_data.iterrows():
                if row["Model"] == selected_model:
                    fig.add_trace(go.Scatterpolar(
                        r=[row["Accuracy"], row["Precision"], row["Recall"], row["F1-Score"]],
                        theta=["Accuracy", "Precision", "Recall", "F1-Score"],
                        fill='toself',
                        name=row["Model"],
                        line_color='red',
                        opacity=0.8
                    ))
                else:
                    fig.add_trace(go.Scatterpolar(
                        r=[row["Accuracy"], row["Precision"], row["Recall"], row["F1-Score"]],
                        theta=["Accuracy", "Precision", "Recall", "F1-Score"],
                        fill='toself',
                        name=row["Model"],
                        opacity=0.3
                    ))
            
            fig.update_layout(
                polar=dict(radialaxis=dict(visible=True, range=[80, 100])),
                showlegend=True,
                title="Performance Comparison"
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Bar chart for individual metrics
            metrics = ["Accuracy", "Precision", "Recall", "F1-Score"]
            values = [model_info["accuracy"], model_info["precision"], 
                     model_info["recall"], model_info["f1_score"]]
            
            fig = px.bar(
                x=metrics, y=values,
                title=f"{selected_model} Performance Metrics",
                color=values,
                color_continuous_scale="RdYlGn"
            )
            fig.update_layout(showlegend=False, yaxis_range=[80, 100])
            st.plotly_chart(fig, use_container_width=True)
        
        # Confusion matrix simulation
        st.subheader("🔍 Model Performance Details")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.subheader("Confusion Matrix")
            # Simulate confusion matrix based on metrics
            accuracy = model_info["accuracy"] / 100
            precision = model_info["precision"] / 100
            recall = model_info["recall"] / 100
            
            # Calculate confusion matrix values
            tp = int(recall * 1000)  # True positives
            fn = int((1 - recall) * 1000)  # False negatives
            fp = int(tp * (1 - precision) / precision) if precision > 0 else 0  # False positives
            tn = 2000 - tp - fn - fp  # True negatives
            
            confusion_matrix = np.array([[tn, fp], [fn, tp]])
            
            fig = px.imshow(
                confusion_matrix, 
                text_auto=True,
                aspect="auto",
                color_continuous_scale="Blues",
                title="Predicted vs Actual"
            )
            fig.update_xaxes(ticktext=["No Fire", "Fire"], tickvals=[0, 1])
            fig.update_yaxes(ticktext=["No Fire", "Fire"], tickvals=[0, 1])
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            st.subheader("Training History")
            # Simulate training history
            epochs = list(range(1, 51))
            train_acc = [85 + 10 * (1 - np.exp(-i/15)) + np.random.normal(0, 0.5) for i in epochs]
            val_acc = [83 + 8 * (1 - np.exp(-i/12)) + np.random.normal(0, 0.8) for i in epochs]
            
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=epochs, y=train_acc, mode='lines', name='Training'))
            fig.add_trace(go.Scatter(x=epochs, y=val_acc, mode='lines', name='Validation'))
            fig.update_layout(
                title="Training Progress",
                xaxis_title="Epoch",
                yaxis_title="Accuracy (%)"
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with col3:
            st.subheader("Model Efficiency")
            
            # Training efficiency metrics
            st.metric("Training Speed", f"{model_info['training_samples'] // (int(model_info['training_time'].split()[0]) * 60):,} samples/min")
            st.metric("Memory Usage", f"{float(model_info['parameters'].replace('M', '')) * 4:.1f} MB")
            st.metric("Inference Time", f"{np.random.uniform(0.5, 5.0):.2f} ms")
            
            # ROC curve simulation
            fpr = np.linspace(0, 1, 100)
            tpr = np.sqrt(fpr) * (model_info["accuracy"] / 100)
            
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=fpr, y=tpr, mode='lines', name='ROC Curve'))
            fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode='lines', name='Random', line=dict(dash='dash')))
            fig.update_layout(
                title="ROC Curve",
                xaxis_title="False Positive Rate",
                yaxis_title="True Positive Rate"
            )
            st.plotly_chart(fig, use_container_width=True)
    
    with tab3:
        st.header("🧠 Methodology & Implementation")
        
        if "CNN" in selected_model:
            st.subheader("🖼️ Convolutional Neural Network Approach")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("""
                **Key Features:**
                - Pre-trained ResNet50 backbone for feature extraction
                - Transfer learning from ImageNet
                - Spatial attention mechanisms
                - Multi-scale feature fusion
                - Data augmentation techniques
                
                **Input Processing:**
                - Satellite imagery (RGB + NIR channels)
                - Image normalization and standardization
                - Patch-based processing for large images
                - Real-time preprocessing pipeline
                """)
            
            with col2:
                st.markdown("""
                **Training Strategy:**
                - Progressive resizing (224x224 → 512x512)
                - Learning rate scheduling with warmup
                - Mixed precision training
                - Gradient clipping and regularization
                - Early stopping based on validation loss
                
                **Optimization:**
                - Adam optimizer with β₁=0.9, β₂=0.999
                - Initial learning rate: 0.001
                - Weight decay: 0.0001
                - Batch size: 32
                """)
        
        elif "LSTM" in selected_model:
            st.subheader("🔄 Long Short-Term Memory Approach")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("""
                **Time Series Features:**
                - Temperature, humidity, wind speed
                - Precipitation and atmospheric pressure
                - Vegetation indices (NDVI, EVI)
                - Historical fire occurrence patterns
                - Seasonal and cyclical components
                
                **Sequence Processing:**
                - Variable-length input sequences
                - Attention mechanisms for important time steps
                - Bidirectional LSTM layers
                - Dropout for regularization
                """)
            
            with col2:
                st.markdown("""
                **Model Architecture:**
                - Input embedding layer (64 dimensions)
                - 2 LSTM layers (128, 64 units)
                - Dropout layers (0.3 rate)
                - Dense layers for classification
                - Sigmoid activation for probability output
                
                **Training Configuration:**
                - Sequence length: 168 hours (7 days)
                - Batch size: 64
                - Learning rate: 0.002
                - Gradient clipping: 1.0
                """)
        
        elif "Ensemble" in selected_model:
            st.subheader("🎭 Ensemble Learning Approach")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("""
                **Component Models:**
                - CNN for spatial features (satellite imagery)
                - LSTM for temporal patterns (weather data)
                - Random Forest for tabular features
                - Gradient Boosting for non-linear relationships
                
                **Feature Integration:**
                - Multi-modal data fusion
                - Attention-based weighting
                - Cross-modal feature alignment
                - Hierarchical feature extraction
                """)
            
            with col2:
                st.markdown("""
                **Ensemble Strategy:**
                - Weighted voting based on model confidence
                - Dynamic weight adjustment
                - Stacking with meta-learner
                - Diversity maximization techniques
                
                **Performance Benefits:**
                - Reduced overfitting through diversity
                - Better generalization across scenarios
                - Robust predictions under uncertainty
                - Improved confidence estimation
                """)
        
        else:  # Transformer
            st.subheader("🔀 Vision Transformer Approach")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("""
                **Architecture Components:**
                - Patch embedding (16x16 patches)
                - Positional encoding
                - 12 transformer encoder layers
                - Multi-head self-attention (8 heads)
                - Layer normalization and residual connections
                
                **Attention Mechanism:**
                - Global spatial relationships
                - Long-range dependency modeling
                - Dynamic feature weighting
                - Interpretable attention maps
                """)
            
            with col2:
                st.markdown("""
                **Training Strategy:**
                - Pre-training on large satellite datasets
                - Fine-tuning on fire risk data
                - Progressive image size increase
                - Mixup and CutMix augmentation
                
                **Optimization:**
                - AdamW optimizer
                - Cosine annealing learning rate schedule
                - Gradient accumulation (effective batch size: 512)
                - Label smoothing (0.1)
                """)
    
    with tab4:
        st.header("⚙️ Training Details & Configuration")
        
        # Training configuration
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("📊 Training Statistics")
            
            training_stats = pd.DataFrame({
                'Metric': ['Training Samples', 'Validation Samples', 'Test Samples', 'Parameters', 'Training Time', 'Epochs'],
                'Value': [f"{model_info['training_samples']:,}", f"{model_info['validation_samples']:,}", 
                         f"{model_info['validation_samples']//2:,}", model_info['parameters'], 
                         model_info['training_time'], "50"]
            })
            
            st.dataframe(training_stats, hide_index=True)
            
            # Hardware requirements
            st.subheader("💻 Hardware Requirements")
            if "CNN" in selected_model or "Transformer" in selected_model:
                st.markdown("""
                - **GPU**: NVIDIA V100 or better
                - **Memory**: 32GB+ GPU memory
                - **Storage**: 100GB+ SSD
                - **CPU**: 16+ cores recommended
                """)
            else:
                st.markdown("""
                - **GPU**: NVIDIA RTX 3080 or better
                - **Memory**: 16GB+ GPU memory
                - **Storage**: 50GB+ SSD
                - **CPU**: 8+ cores recommended
                """)
        
        with col2:
            st.subheader("🔧 Hyperparameters")
            
            if "CNN" in selected_model:
                hyperparams = {
                    'Learning Rate': '0.001',
                    'Batch Size': '32',
                    'Optimizer': 'Adam',
                    'Weight Decay': '0.0001',
                    'Dropout Rate': '0.5',
                    'Image Size': '224x224'
                }
            elif "LSTM" in selected_model:
                hyperparams = {
                    'Learning Rate': '0.002',
                    'Batch Size': '64',
                    'Sequence Length': '168',
                    'Hidden Units': '128, 64',
                    'Dropout Rate': '0.3',
                    'Optimizer': 'Adam'
                }
            elif "Ensemble" in selected_model:
                hyperparams = {
                    'Ensemble Method': 'Weighted Voting',
                    'CNN Weight': '0.4',
                    'LSTM Weight': '0.35',
                    'RF Weight': '0.25',
                    'Meta Learner': 'Logistic Regression',
                    'Cross Validation': '5-fold'
                }
            else:  # Transformer
                hyperparams = {
                    'Learning Rate': '0.0001',
                    'Batch Size': '16',
                    'Patch Size': '16x16',
                    'Attention Heads': '8',
                    'Encoder Layers': '12',
                    'Hidden Dim': '768'
                }
            
            hyperparams_df = pd.DataFrame(list(hyperparams.items()), columns=['Parameter', 'Value'])
            st.dataframe(hyperparams_df, hide_index=True)
        
        # Model deployment info
        st.subheader("🚀 Deployment Configuration")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("""
            **Production Setup:**
            - Docker containerization
            - Kubernetes orchestration
            - Auto-scaling based on load
            - Health monitoring
            - Logging and metrics collection
            """)
        
        with col2:
            st.markdown("""
            **API Specifications:**
            - REST API endpoints
            - Real-time prediction service
            - Batch processing capability
            - Rate limiting and authentication
            - Response time SLA: <500ms
            """)
        
        with col3:
            st.markdown("""
            **Monitoring & Alerts:**
            - Model drift detection
            - Performance degradation alerts
            - Data quality monitoring
            - Automated retraining triggers
            - A/B testing framework
            """)

if __name__ == "__main__":
    main()